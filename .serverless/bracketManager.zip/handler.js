"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const Alexa = require("alexa-sdk");
const APP_ID = '';
const HELP_MESSAGE = 'This is a temp help message';
const HELP_REPROMPT = 'Reprompt for Help';
const STOP_MESSAGE = 'We are stopping';
function main(event, context, callback) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(event);
        console.log(context);
        let alexa = Alexa.handler(event, context);
        alexa.appId = APP_ID;
        alexa.registerHandlers(alexaHandlers);
        alexa.execute();
    });
}
exports.main = main;
const alexaHandlers = {
    'startNewBracket': () => {
    },
    'describeBracketStatus': () => {
    },
    'describeMatch': () => {
    },
    'describeNextMatch': () => {
    },
    'getTeamStats': () => {
    },
    'listTeams': () => {
    },
    'submitMatchScores': () => {
    },
    'AMAZON.HelpIntent': function () {
        const speechOutput = HELP_MESSAGE;
        const reprompt = HELP_REPROMPT;
        this.response.speak(speechOutput).listen(reprompt);
        this.emit(':responseReady');
    },
    'AMAZON.CancelIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
    'AMAZON.StopIntent': function () {
        this.response.speak(STOP_MESSAGE);
        this.emit(':responseReady');
    },
};
